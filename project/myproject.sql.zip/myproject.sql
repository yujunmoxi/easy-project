-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2017 年 03 月 16 日 12:27
-- 服务器版本: 5.5.8
-- PHP 版本: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `myproject`
--

-- --------------------------------------------------------

--
-- 表的结构 `index`
--

CREATE TABLE IF NOT EXISTS `index` (
  `src` varchar(100) NOT NULL,
  `name1` varchar(50) NOT NULL,
  `name2` varchar(50) NOT NULL,
  `price` varchar(20) NOT NULL,
  `oldprice` varchar(20) NOT NULL,
  `cutprice` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `index`
--

INSERT INTO `index` (`src`, `name1`, `name2`, `price`, `oldprice`, `cutprice`) VALUES
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'HOLIKA HOLIKA 好利卡好利卡 ', '猪鼻子去黑头收毛孔三部曲 10片', '¥79.00', '¥119.00', '立省 ¥40.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'PAPA RECIPE ', '春雨蜂蜜面膜10片', '¥79.00', '¥149.00', '立省 ¥70.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'AHC ', 'B5玻尿酸爽肤水', '¥79.00', '¥129.00', '立省 ¥50.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', '贵爱娘 ', '卫生巾日用 18片 (290mm)', '¥29.00', '¥59.00', '立省 ¥30.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'JAYJUN ', '鳄鱼素颜霜70g', '¥97.00', '¥149.00', '立省 ¥52.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'JAYJUN ', '水光再生泡沫洗面奶 150ml', '¥85.00', '¥94.00', '立省 ¥9.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'WHOO 后 ', '津率享 红华凝香洁面乳 180ml', '¥259.00', '¥350.00', '立省 ¥91.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'TOO COOL FOR SCHOOL ', '格子修容腮红', '¥82.00', '¥149.00', '立省 ¥67.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'THE SAEM 得鲜 ', '双头卧蚕笔', '¥29.00', '¥49.00', '立省 ¥20.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'BANILACO 芭妮兰 ', '保湿幻彩修颜液妆前乳', '¥104.00', '¥188.00', '立省 ¥84.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'CLIO 珂莱欧 ', '魅棕持久两用眉笔 002浅棕色', '¥142.00', '¥199.00', '立省 ¥57.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'CLIO 珂莱欧 ', '少女之吻雾感唇膏', '¥119.00', '¥169.00', '立省 ¥50.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'ETUDE HOUSE 伊蒂之屋 ', '时尚精巧持久型眼线笔', '¥19.00', '¥29.00', '立省 ¥10.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'ETUDE HOUSE 伊蒂之屋 ', '唇唇欲动遮瑕唇膏', '¥37.00', '¥58.00', '立省 ¥21.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'ETUDE HOUSE 伊蒂之屋 ', 'BB深层卸妆泡沫洗面奶', '¥55.00', '¥69.00', '立省 ¥14.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'JAYJUN ', '黑色水光面膜三部曲 10片', '¥85.00', '¥159.00', '立省 ¥74.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'BANILACO 芭妮兰 ', '卸妆膏/霜180ml温和卸妆深层清洁限量版', '¥134.00', '¥260.00', '立省 ¥126.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'LANEIGE 兰芝 ', '多效净肤洁颜膏', '¥104.00', '¥205.00', '立省 ¥101.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'LANEIGE 兰芝 ', '双色立体唇膏', '¥131.00', '¥185.00', '立省 ¥54.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'JAYJUN ', '水光再生泡沫洗面奶 150ml*2支', '¥160.00', '¥179.00', '立省 ¥19.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'RYO 吕 ', '臻参宝焕活滋养洗护两件套', '¥79.00', '¥99.00', '立省 ¥20.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'ETUDE HOUSE 伊蒂之屋 ', '唇部磨砂膏3支', '¥74.00', '¥119.00', '立省 ¥45.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'DEWYTREE 自颜源露 ', '白大褂酵素活力面膜绿色 10片', '¥86.00', '¥139.00', '立省 ¥53.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'DEWYTREE 自颜源露 ', '白大褂酵素活力面膜黄色 10片', '¥86.00', '¥139.00', '立省 ¥53.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'INNISFREE 悦诗风吟 ', '绿茶精萃平衡面霜', '¥89.00', '¥135.00', '立省 ¥46.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'INNISFREE 悦诗风吟 ', '控油矿物质散粉', '¥35.00', '¥50.00', '立省 ¥15.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'SKINFOOD 思亲肤 ', '香芹菜柳橙舒缓水160ml', '¥52.00', '¥80.00', '立省 ¥28.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'SKINFOOD 思亲肤 ', '芹菜柳橙舒緩乳液 160ml', '¥52.00', '¥80.00', '立省 ¥28.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'PERIPERA 菲丽菲拉 ', 'Peri`s 魅惑墨水唇彩', '¥29.00', '¥84.00', '立省 ¥55.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'MEDIHEAL 美迪惠尔 ', '茶树面膜贴 10片', '¥74.00', '¥129.00', '立省 ¥55.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'SKINFOOD 思亲肤 ', '青葡萄唤醒粉饼', '¥59.00', '¥107.00', '立省 ¥48.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'SKINFOOD 思亲肤 ', '小麦清透定妆散粉', '¥49.00', '¥80.00', '立省 ¥31.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', '贵爱娘 ', '卫生护垫加长款 1包 38片装', '¥29.00', '¥45.00', '立省 ¥16.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'CHARMZONE 婵真 ', '银杏自然泡沫洗面奶', '¥52.00', '¥99.00', '立省 ¥47.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'ETUDE HOUSE 伊蒂之屋 ', '水满胶原清凝弹力面霜 75ml', '¥44.00', '¥79.00', '立省 ¥35.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'Heynature ', '双重机能性BB霜 SPF35 40g', '¥71.00', '¥159.00', '立省 ¥88.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'ETUDE HOUSE 伊蒂之屋 ', '唇部磨砂膏', '¥22.00', '¥39.00', '立省 ¥17.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'THE FACE SHOP 菲诗小铺 ', '金盏花柔嫩精华乳', '¥88.00', '¥109.00', '立省 ¥21.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'L''AFFAIR 莱妃尔 ', '熊猫莹润面膜 10片', '¥71.00', '¥169.00', '立省 ¥98.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', '贵爱娘 ', '卫生巾日用 18片 (250mm)', '¥29.00', '¥49.00', '立省 ¥20.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'MISSHA 谜尚 ', 'LINE FRIENDS 优护水润精华防晒霜SPF30+/PA+++[恋朋限量版]', '¥82.00', '¥128.00', '立省 ¥46.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'MISSHA 谜尚 ', 'LINE FRIENDS 优护水嫩防晒霜SPF24/PA++[恋朋限量版]', '¥82.00', '¥128.00', '立省 ¥46.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'DEWYTREE自颜源露 ', '白大褂酵素水润面膜红色 10片', '¥86.00', '¥119.00', '立省 ¥33.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'NATURE REPUBLIC 纳益其尔 ', '芦荟面膜 10片', '¥37.00', '¥79.00', '立省 ¥42.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'NATURE REPUBLIC 自然共和国 ', '番茄水润面膜 10片', '¥37.00', '¥79.00', '立省 ¥42.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'NATURE REPUBLIC 纳益其尔 ', '蜂王浆水润滋养面膜 10片', '¥37.00', '¥79.00', '立省 ¥42.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'NATURE REPUBLIC 纳益其尔 ', '乳木果油滋养保湿面膜 10片', '¥37.00', '¥79.00', '立省 ¥42.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'NATURE REPUBLIC 纳益其尔 ', '鳄梨柔润紧致面膜 10片', '¥37.00', '¥79.00', '立省 ¥42.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'NATURE REPUBLIC 纳益其尔 ', '阿萨伊浆果弹力滋养面膜 10片', '¥37.00', '¥79.00', '立省 ¥42.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'VOV ', '清透丝柔蜜粉 21象牙白', '¥112.00', '¥199.00', '立省 ¥87.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'SKINFOOD 思亲肤 ', '黄金奇异果Q亮化妆水 150ml', '¥67.00', '¥150.00', '立省 ¥83.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'SKINFOOD 思亲肤 ', '西红柿番茄化妆水 135ml', '¥59.00', '¥149.00', '立省 ¥90.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'SKINFOOD 思亲肤 ', '黑糖草莓焕彩面膜(洗净式)', '¥59.00', '¥85.00', '立省 ¥26.00'),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8', 'SKINFOOD 思亲肤 ', '水蜜桃清酒紧致乳液135ml', '¥52.00', '¥95.00', '立省 ¥43.00');

-- --------------------------------------------------------

--
-- 表的结构 `lili`
--

CREATE TABLE IF NOT EXISTS `lili` (
  `src` varchar(200) NOT NULL,
  `h3` varchar(200) NOT NULL,
  `h4` varchar(200) NOT NULL,
  `span` varchar(100) NOT NULL,
  `span1` varchar(20) NOT NULL,
  `p` varchar(20) NOT NULL,
  `button` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `lili`
--

INSERT INTO `lili` (`src`, `h3`, `h4`, `span`, `span1`, `p`, `button`) VALUES
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/r/prd_1601082307548140.jpg', 'BANILACO 芭妮兰 ', '致柔水润卸妆膏 100ml', '¥89.00', '¥179.00', '立省 ¥100.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/-/_-10__2.jpg', 'HOLIKA HOLIKA 好利卡好利卡 ', '猪鼻子去黑头收毛孔三部曲 10片', '¥89.00', '¥119.00', '立省 ¥40.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/a/papa-recipe-_-10_.jpg', 'PAPA RECIPE ', '春雨蜂蜜面膜10片', '¥89.00', '¥149.00', '立省 ¥70.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/a/h/ahc-b5_100ml-1.jpg', 'AHC ', 'B5玻尿酸爽肤水', '¥89.00', '¥129.00', '立省 ¥50.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/-/_-_-18_-_290mm__1.jpg', '贵爱娘 ', '卫生巾日用 18片 (290mm)', '¥89.00', '¥59.00', '立省 ¥30.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/1/_/1_1__3.jpg', 'JAYJUN ', '鳄鱼素颜霜70g', '¥89.00', '¥149.00', '立省 ¥52.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_196_24.jpg', 'JAYJUN ', '水光再生泡沫洗面奶 150ml', '¥89.00', '¥94.00', '立省 ¥9.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/-/_-__6_16.jpg', 'WHOO 后 ', '津率享 红华凝香洁面乳 180ml', '¥89.00', '¥350.00', '立省 ¥91.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/t/o/too-cool-for-school-__2.jpg', 'TOO COOL FOR SCHOOL ', '格子修容腮红', '¥89.00', '¥149.00', '立省 ¥67.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_199_95.jpg', 'THE SAEM 得鲜 ', '双头卧蚕笔', '¥89.00', '¥49.00', '立省 ¥20.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/c/0/c040003.jpg', 'BANILACO 芭妮兰 ', '保湿幻彩修颜液妆前乳', '¥89.00', '¥188.00', '立省 ¥84.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/c/0/c050026_1.png', 'CLIO 珂莱欧 ', '魅棕持久两用眉笔 002浅棕色', '¥89.00', '¥199.00', '立省 ¥57.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/c/l/clio-_-__2.jpg', 'CLIO 珂莱欧 ', '少女之吻雾感唇膏', '¥89.00', '¥169.00', '立省 ¥50.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/s/t/styling_.jpg', 'ETUDE HOUSE 伊蒂之屋 ', '时尚精巧持久型眼线笔', '¥89.00', '¥29.00', '立省 ¥10.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/e/t/etude-house-_-__7.jpg', 'ETUDE HOUSE 伊蒂之屋 ', '唇唇欲动遮瑕唇膏', '¥89.00', '¥58.00', '立省 ¥21.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/-/_-1_11_20.jpg', 'ETUDE HOUSE 伊蒂之屋 ', 'BB深层卸妆泡沫洗面奶', '¥89.00', '¥69.00', '立省 ¥14.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/j/a/jayjun-_.jpg', 'JAYJUN ', '黑色水光面膜三部曲 10片', '¥89.00', '¥159.00', '立省 ¥74.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_200_3.jpg', 'BANILACO 芭妮兰 ', '卸妆膏/霜180ml温和卸妆深层清洁限量版', '¥89.00', '¥260.00', '立省 ¥126.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/t/b/tb1lfm4jfxxxxahxpxxxxxxxxxx__0-item_pic_3.jpg', 'LANEIGE 兰芝 ', '多效净肤洁颜膏', '¥89.00', '¥205.00', '立省 ¥101.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/1/3/13-22laneige_-_2g-_.jpg', 'LANEIGE 兰芝 ', '双色立体唇膏', '¥89.00', '¥185.00', '立省 ¥54.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/1/4/14.jayjun_150ml_2_.jpg', 'JAYJUN ', '水光再生泡沫洗面奶 150ml*2支', '¥89.00', '¥179.00', '立省 ¥19.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_202_2.jpg', 'RYO 吕 ', '臻参宝焕活滋养洗护两件套', '¥89.00', '¥99.00', '立省 ¥20.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/3/_3__2_3.jpg', 'ETUDE HOUSE 伊蒂之屋 ', '唇部磨砂膏3支', '¥89.00', '¥119.00', '立省 ¥45.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/1/_/1._-_.jpg', 'DEWYTREE 自颜源露 ', '白大褂酵素活力面膜绿色 10片', '¥89.00', '¥139.00', '立省 ¥53.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/2/_/2._-_.jpg', 'DEWYTREE 自颜源露 ', '白大褂酵素活力面膜黄色 10片', '¥89.00', '¥139.00', '立省 ¥53.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_187_5.jpg', 'INNISFREE 悦诗风吟 ', '绿茶精萃平衡面霜', '¥89.00', '¥135.00', '立省 ¥46.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/-/_-__6_48.jpg', 'INNISFREE 悦诗风吟 ', '控油矿物质散粉', '¥89.00', '¥50.00', '立省 ¥15.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_199_101.jpg', 'SKINFOOD 思亲肤 ', '香芹菜柳橙舒缓水160ml', '¥89.00', '¥80.00', '立省 ¥28.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/s/k/skinfood_160ml_2.jpg', 'SKINFOOD 思亲肤 ', '芹菜柳橙舒緩乳液 160ml', '¥89.00', '¥80.00', '立省 ¥28.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/s/ds104_1_2.jpg', 'PERIPERA 菲丽菲拉 ', 'Peri`s 魅惑墨水唇彩', '¥89.00', '¥84.00', '立省 ¥55.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/-/_-_mei_2.jpg', 'MEDIHEAL 美迪惠尔 ', '茶树面膜贴 10片', '¥89.00', '¥129.00', '立省 ¥55.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_201_8.jpg', 'SKINFOOD 思亲肤 ', '青葡萄唤醒粉饼', '¥89.00', '¥107.00', '立省 ¥48.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_206_2.jpg', 'SKINFOOD 思亲肤 ', '小麦清透定妆散粉', '¥89.00', '¥80.00', '立省 ¥31.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/s/2/s2332_1_2.jpg', '贵爱娘 ', '卫生护垫加长款 1包 38片装', '¥89.00', '¥45.00', '立省 ¥16.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/c/h/charmzone-_-_-200g.jpg', 'CHARMZONE 婵真 ', '银杏自然泡沫洗面奶', '¥89.00', '¥99.00', '立省 ¥47.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/e/t/etude-house-_-__3.jpg', 'ETUDE HOUSE 伊蒂之屋 ', '水满胶原清凝弹力面霜 75ml', '¥89.00', '¥79.00', '立省 ¥35.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/c/0/c080019.jpg', 'Heynature ', '双重机能性BB霜 SPF35 40g', '¥89.00', '¥159.00', '立省 ¥88.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/c/0/c060011.jpg', 'ETUDE HOUSE 伊蒂之屋 ', '唇部磨砂膏', '¥89.00', '¥39.00', '立省 ¥17.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_199_62.jpg', 'THE FACE SHOP 菲诗小铺 ', '金盏花柔嫩精华乳', '¥89.00', '¥109.00', '立省 ¥21.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/l/_/l_affair-_--10__1.jpg', 'L''AFFAIR 莱妃尔 ', '熊猫莹润面膜 10片', '¥89.00', '¥169.00', '立省 ¥98.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/-/_-_-18_-_250mm_.jpg', '贵爱娘 ', '卫生巾日用 18片 (250mm)', '¥89.00', '¥49.00', '立省 ¥20.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/m/i/missha-_-line-friends-_.jpg.jpg', 'MISSHA 谜尚 ', 'LINE FRIENDS 优护水润精华防晒霜SPF30+/PA+++[恋朋限量版]', '¥89.00', '¥128.00', '立省 ¥46.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/l/i/line_friends_spf24_pa_.jpg', 'MISSHA 谜尚 ', 'LINE FRIENDS 优护水嫩防晒霜SPF24/PA++[恋朋限量版]', '¥89.00', '¥128.00', '立省 ¥46.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/4/_/4._-_.jpg', 'DEWYTREE自颜源露 ', '白大褂酵素水润面膜红色 10片', '¥89.00', '¥119.00', '立省 ¥33.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/-/_-23ml10__1.jpg', 'NATURE REPUBLIC 纳益其尔 ', '芦荟面膜 10片', '¥89.00', '¥79.00', '立省 ¥42.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/-/_-23ml-10__4.jpg', 'NATURE REPUBLIC 自然共和国 ', '番茄水润面膜 10片', '¥89.00', '¥79.00', '立省 ¥42.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/-/_-23ml-10__6.jpg', 'NATURE REPUBLIC 纳益其尔 ', '蜂王浆水润滋养面膜 10片', '¥89.00', '¥79.00', '立省 ¥42.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/-/_-23ml-10_.jpg', 'NATURE REPUBLIC 纳益其尔 ', '乳木果油滋养保湿面膜 10片', '¥89.00', '¥79.00', '立省 ¥42.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/-/_-23ml-10__2.jpg', 'NATURE REPUBLIC 纳益其尔 ', '鳄梨柔润紧致面膜 10片', '¥89.00', '¥79.00', '立省 ¥42.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/-/_-23ml-10__1.jpg', 'NATURE REPUBLIC 纳益其尔 ', '阿萨伊浆果弹力滋养面膜 10片', '¥89.00', '¥79.00', '立省 ¥42.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/3/3/333_1.jpg', 'VOV ', '清透丝柔蜜粉 21象牙白', '¥89.00', '¥199.00', '立省 ¥87.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/c/0/c090036.jpg', 'SKINFOOD 思亲肤 ', '黄金奇异果Q亮化妆水 150ml', '¥89.00', '¥150.00', '立省 ¥83.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/c/0/c090034.jpg', 'SKINFOOD 思亲肤 ', '西红柿番茄化妆水 135ml', '¥89.00', '¥149.00', '立省 ¥90.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/s/k/skinfood_100g_1.jpg', 'SKINFOOD 思亲肤 ', '黑糖草莓焕彩面膜(洗净式)', '¥89.00', '¥85.00', '立省 ¥26.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/s/k/skinfood_-_135ml.png', 'SKINFOOD 思亲肤 ', '水蜜桃清酒紧致乳液135ml', '¥89.00', '¥95.00', '立省 ¥43.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/r/dr.althea-_-__6.jpg', 'Dr.Althea 艾医生 ', '水光面霜', '¥89.00', '¥392.00', '立省 ¥249.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/s/ds171_3.jpg', 'LANEIGE 兰芝 ', '雪纱防晒妆前打底隔离霜 SPF 22 PA++', '¥89.00', '', 'Regular Price:', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/v/dv243_1.jpg', 'BANILACO 芭妮兰 ', '致柔卸妆膏 2盒装', '¥89.00', '¥328.00', '立省 ¥140.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/c/n/cn_8.8_63001079_it_s-skin-box_thumb.jpg', 'IT''S SKIN 伊思 ', '晶钻美肌礼盒', '¥89.00', '¥708.00', '立省 ¥385.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/c/n/cn_8.16_63001172_sulhwasoowhitening_box_thumbnail.jpg', 'SULWHASOO 雪花秀 ', '滋晶雪颜凝脂礼盒', '¥89.00', '¥1,157.00', '立省 ¥169.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52001999.jpg', 'LANEIGE 兰芝 ', '致美紧颜修护精华液', '¥89.00', '', 'Regular Price:', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/c/n/cn_10.20_63000586_it_s-skin-snail-box_thumbnail.jpg', 'IT''S SKIN 伊思 ', '水润美肌蜗牛礼盒', '¥89.00', '¥678.00', '立省 ¥340.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/s/ds577.jpg', 'THE FACE SHOP 菲诗小铺 ', '水光保湿气垫CC霜 NEO款', '¥89.00', '¥184.00', '立省 ¥49.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/s/ds578-.jpg', 'THE FACE SHOP 菲诗小铺 ', '水光无瑕气垫CC霜 MUZI款', '¥89.00', '¥184.00', '立省 ¥49.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/s/ds579.jpg', 'THE FACE SHOP 菲诗小铺 ', '控油补水气垫粉底 APEACH款', '¥89.00', '¥184.00', '立省 ¥76.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/c/n/cn_8.2_63000722_the-oozoo-box_thumbnail.jpg', 'THE OOZOO ', 'NEW宇宙针剂面膜礼盒', '¥89.00', '¥840.00', '立省 ¥501.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/c/n/cn_7.4_63000759_leaders-skinseedmask_box_thumbnail_02.jpg', 'LEADERS丽得姿 ', '细胞种子系列面膜礼盒', '¥89.00', '¥960.00', '立省 ¥648.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/v/dv442_1.jpg', 'SHELIM ', '[VDL] 贝壳提亮液妆前乳+[SHELIM] 高保湿绿茶面膜 10片装', '¥89.00', '¥168.00', '立省 ¥52.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51003334-.jpg', 'INNISFREE 悦诗风吟 ', '无油光天然矿物质散粉 3个', '¥89.00', '¥192.00', '立省 ¥51.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/c/n/cn_7.14_63000803_aritaum-makeup-box_thumb.jpg', 'ARITAUM 爱茉莉 ', '甜美彩妆礼盒', '¥89.00', '¥334.00', '立省 ¥155.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52005186_1.jpg', 'T.P.O ', '恋朋可妮兔三部曲鼻贴 5片', '¥89.00', '¥120.00', '立省 ¥51.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52000499_2.jpg', 'WHOO 后 ', '拱辰享雪 玉凝系列礼盒5件套', '¥89.00', '¥1,586.00', '立省 ¥487.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52000247_1.jpg', 'VANT36.5 ', '水光气垫CC霜', '¥89.00', '¥200.00', '立省 ¥51.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51001643.jpg', 'VDL ', '贝壳提亮液妆前乳', '¥89.00', '¥168.00', '立省 ¥50.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/1/3/13-22laneige_-_2g-__2.jpg', 'LANEIGE 兰芝 ', '双色立体唇膏', '¥89.00', '¥185.00', '立省 ¥42.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51001622.jpg', 'INNISFREE 悦诗风吟 ', '绿茶保湿乳液', '¥89.00', '¥115.00', '立省 ¥6.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/i/n/innisfree-_-__1_14.jpg', 'INNISFREE 悦诗风吟 ', '绿茶保湿爽肤水', '¥89.00', '¥115.00', '立省 ¥6.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/0/50001484.jpg', 'INNISFREE 悦诗风吟 ', '绿茶籽水分营养精华', '¥89.00', '¥210.00', '立省 ¥71.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/i/t/it_s-skin__1.jpg', 'IT''S SKIN 伊思 ', '晶钻蜗牛泡沫洗面奶', '¥89.00', '¥128.00', '立省 ¥53.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51001994.jpg', 'SULWHASOO 雪花秀 ', '宫中蜜皂', '¥89.00', '¥336.00', '立省 ¥66.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/t/h/thumbnail-changes1338_1_1.jpg', 'ETUDE HOUSE 伊蒂之屋 ', '美颜柔雾霜妆前乳', '¥89.00', '¥120.00', '立省 ¥16.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52001726.jpg', 'SULWHASOO 雪花秀 ', '弹力肌本紧然修颜霜', '¥89.00', '', 'Regular Price:', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52002272.jpg', 'VANT36.5 ', '水光f防晒气垫CC霜', '¥89.00', '¥204.00', '立省 ¥65.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/j/a/jayjun__2.jpg', 'JAYJUN ', '胎盘面膜 5片装', '¥89.00', '¥392.00', '立省 ¥217.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52006026_5.jpg', 'WHOO 后 ', '秘贴 焕然新生精华液礼盒5件套', '¥89.00', '¥1,405.00', '立省 ¥159.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52005222.jpg', 'SULWHASOO 雪花秀 ', '滋阴生人参真本油', '¥89.00', '¥960.00', '立省 ¥261.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/r/dr.althea-_-__13.jpg', 'Dr.Althea 艾医生 ', '水光针美白面膜 5片', '¥89.00', '¥240.00', '立省 ¥123.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/s/2/s2317_1.jpg', 'THE SAEM 得鲜 ', '茶树卸妆水', '¥89.00', '¥44.00', '立省 ¥5.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/0/50002162.jpg', 'THE SAEM 得鲜 ', '电眼卧蚕笔', '¥89.00', '美美箱优惠价', '立省 -¥2.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/s/ds146.jpg', 'THE FACE SHOP 菲诗小铺 ', '双头遮瑕液', '¥89.00', '¥87.00', '立省 ¥7.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51000862.jpg', 'SKINFOOD 思亲肤 ', '黄金鱼子酱赋活霜', '¥89.00', '¥176.00', '立省 ¥25.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/s/ds89-1.jpg', 'TOO COOL FOR SCHOOL ', '迪诺恐龙滋养护唇膏', '¥89.00', '¥96.00', '立省 ¥16.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/a/_/a_pieu-_-__23.jpg', 'A''PIEU 奥普 ', '双色双头遮瑕液', '¥89.00', '¥44.00', '立省 ¥5.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/b/a/banilaco-_--primer-classic-_30ml-_.jpg', 'BANILACO 芭妮兰 ', '幻彩修颜液', '¥89.00', '¥176.00', '立省 ¥51.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52001145.jpg', 'DERMA LIFT ', '水盈滋润舒颜水', '¥89.00', '¥232.00', '立省 ¥85.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/s/ds83.jpg', 'CLIO 珂莱欧 ', '专业艺术遮瑕棒', '¥89.00', '¥128.00', '立省 ¥9.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/s/ds52_5.jpg', 'ETUDE HOUSE 伊蒂之屋 ', '101多功能防水眼线笔', '¥89.00', '¥48.00', '立省 ¥1.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/t/h/thumbnail-changes945_1.jpg', 'THE SAEM 得鲜 ', '青柠薄荷莫吉托喷雾', '¥89.00', '¥56.00', '立省 ¥7.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52001448.jpg', 'INNISFREE 悦诗风吟 ', '甘蓝抗氧化润肤乳', '¥89.00', '¥70.00', '立省 ¥21.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52000169.jpg', 'GARGLIN ', '齿龈防护漱口水', '¥89.00', '', 'Regular Price:', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/s/ds51_1.jpg', 'ETUDE HOUSE 伊蒂之屋 ', '清纯自然眉毛膏', '¥89.00', '¥78.00', '立省 ¥33.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/s/ds129_1.jpg', 'BERRISOM ', '撕拉式染色唇彩', '¥89.00', '¥120.00', '立省 ¥63.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52001001.jpg', 'TOO COOL FOR SCHOOL ', '艺术课堂素描眉笔', '¥89.00', '¥50.00', '立省 ¥4.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/s/ds216_1.jpg', 'TOO COOL FOR SCHOOL ', '格子蛋糕四色腮红', '¥89.00', '¥136.00', '立省 ¥14.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52001444.jpg', 'INNISFREE 悦诗风吟 ', '燕麦多效合一润肤霜', '¥89.00', '¥70.00', '立省 ¥21.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/s/ds290_1.jpg', 'THE SAEM 得鲜 ', '赛慕单色腮红', '¥89.00', '¥40.00', '立省 ¥2.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/s/ds317_1.jpg', 'CLIO 珂莱欧 ', '立体裸妆10色眼影', '¥89.00', '¥256.00', '立省 ¥96.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/3/5/358-4_1.jpg', 'CLIO 珂莱欧 ', '微热之吻唇蜜 04. 4号 橘红色', '¥89.00', '¥128.00', '立省 ¥49.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52000410.jpg', 'TOO COOL FOR SCHOOL ', '美术课修妆笔', '¥89.00', '¥80.00', '立省 ¥9.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/r/dr.jart_-_-_-5__6.jpg', 'DR.JART+ 蒂佳婷 ', '宛若新生微晶亮白 5片装', '¥89.00', '¥214.00', '立省 ¥78.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_75_2_1.jpg', 'Pony Effect ', '轻奢保湿口红', '¥89.00', '美美箱优惠价', '立省 ¥44.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_146_1.jpg', 'Pony Effect ', '自然双头染眉膏', '¥89.00', '美美箱优惠价', '立省 ¥27.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_120_1.jpg', 'Pony Effect ', '持久保湿丝绒唇釉', '¥89.00', '¥138.00', '立省 ¥19.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/o/pony-effect-__1.jpg', 'Pony Effect ', '纯真染色唇彩', '¥89.00', '¥128.00', '立省 ¥43.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/o/pony-effect-__1_6.jpg', 'Pony Effect ', '私人定制唇彩调色盘', '¥89.00', '', 'Regular Price:', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/o/pony-effect-ve_.jpg', 'Pony Effect ', 'VE双头眉笔', '¥89.00', '¥98.00', '立省 ¥32.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/c/o/coverstaycushionfoundation_thumb1_1.jpg', 'Pony Effect ', '哑光遮瑕气垫粉底霜', '¥89.00', '¥298.00', '立省 ¥114.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/s/q/square_7.jpg', 'Pony Effect ', '幻彩美颜棒', '¥89.00', '', 'Regular Price:', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/o/pony-effect-__1_2.jpg', 'Pony Effect ', '旅行多功能化妆包', '¥89.00', '美美箱优惠价', '立省 ¥47.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/t/h/that-girl_.jpg', 'Pony Effect ', 'THAT GIRL刷套装', '¥89.00', '美美箱优惠价', '立省 ¥60.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/o/pony-effect__3.jpg', 'Pony Effect ', '液体金属眼影', '¥89.00', '¥128.00', '立省 ¥43.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_95_1.jpg', 'Pony Effect ', '磁铁化妆刷框架', '¥89.00', '美美箱优惠价', '立省 ¥72.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_92_2.jpg', 'Pony Effect ', '磁铁粉底液刷#104', '¥89.00', '美美箱优惠价', '立省 ¥52.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/1/_101_4.jpg', 'Pony Effect ', '磁铁散粉刷#101', '¥89.00', '美美箱优惠价', '立省 ¥57.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/2/_205_2.jpg', 'Pony Effect ', '磁铁晕染眼影刷#205', '¥89.00', '美美箱优惠价', '立省 ¥29.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/2/_204_1.jpg', 'Pony Effect ', '磁铁点缀眼影刷#204', '¥89.00', '美美箱优惠价', '立省 ¥29.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/2/_202_1.jpg', 'Pony Effect ', '磁铁中号眼影刷#202', '¥89.00', '美美箱优惠价', '立省 ¥32.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_90_3.jpg', 'Pony Effect ', '磁铁小号眼影刷#201', '¥89.00', '美美箱优惠价', '立省 ¥29.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/2/_203_1.jpg', 'Pony Effect ', '磁铁大号眼影刷#203', '¥89.00', '美美箱优惠价', '立省 ¥34.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/2/_206_2.jpg', 'Pony Effect ', '磁铁眼线刷#206', '¥89.00', '美美箱优惠价', '立省 ¥29.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/1/_102_2.jpg', 'Pony Effect ', '磁铁高光刷#102', '¥89.00', '美美箱优惠价', '立省 ¥34.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/1/_103_2.jpg', 'Pony Effect ', '磁铁腮红、修容化妆刷#103', '¥89.00', '美美箱优惠价', '立省 ¥44.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_91_1.jpg', 'Pony Effect ', '磁铁遮瑕膏、唇彩刷#105', '¥89.00', '美美箱优惠价', '立省 ¥28.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/o/pony-_-__1.jpg', 'Pony ', '花语浪漫口红 （樱花浪漫口红）', '¥89.00', '美美箱优惠价', '立省 ¥25.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/o/pony-effect-__1_3_1.jpg', 'Pony Effect ', '轻奢丝绒口红', '¥89.00', '美美箱优惠价', '立省 ¥44.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/o/pony-effect-__1_4_1.jpg', 'Pony Effect ', '水凝唇釉', '¥89.00', '¥148.00', '立省 ¥44.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/e/v/everlastingcushionfoundation_thumb1.jpg', 'Pony Effect ', '“魔方气垫”光彩气垫粉底霜替换芯', '¥89.00', '', 'Regular Price:', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/c/o/coverstaycushionfoundation_thumb1.jpg', 'Pony Effect ', '哑光遮瑕气垫粉底霜 替换芯', '¥89.00', '', 'Regular Price:', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/o/pony-effect-_-__2.jpg', 'Pony Effect ', '磁铁化妆刷板架 不含刷子', '¥89.00', '美美箱优惠价', '立省 ¥44.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/o/pony_effect__7.jpg', 'Pony Effect ', '珍珠提亮高光液', '¥89.00', '¥178.00', '立省 ¥55.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/s/q/square2_2.jpg', 'Pony Effect ', '防水海滩收纳包', '¥89.00', '美美箱优惠价', '立省 ¥29.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/i/m/image_20150817153136_xadttbr46h_2.jpg', 'Pony ', 'X MEMEBOX 闪耀蜜色8色眼影盘', '¥89.00', '美美箱优惠价', '立省 ¥47.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/i/m/image_20150817153823_9nxyqy2wdf_2.jpg', 'Pony ', 'X MEMEBOX 绚烂星空8色眼影盘', '¥89.00', '美美箱优惠价', '立省 ¥47.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/1/1/119_1_2.jpg', 'Pony ', '幻彩粉嫩腮红 #01 Galaxy Pink 梦幻粉红', '¥89.00', '美美箱优惠价', '立省 ¥25.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_196_12.jpg', 'Pony Effect ', '个性独特腮红', '¥89.00', '¥108.00', '立省 ¥17.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_196_5.jpg', 'Pony Effect ', '咖啡哑光修容盘', '¥89.00', '¥108.00', '立省 ¥18.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/s/q/square2_1.jpg', 'Pony Effect ', '完美妆效粉底液', '¥89.00', '美美箱优惠价', '立省 ¥62.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_197_2.jpg', 'Pony Effect ', '迷幻高光修容盘', '¥89.00', '¥108.00', '立省 ¥17.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/o/pony_effect__2.jpg', 'Pony Effect ', '亲肤遮瑕液', '¥89.00', '¥138.00', '立省 ¥41.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/s/q/square_2.jpg', 'Pony Effect ', '专业眼线液笔', '¥89.00', '¥138.00', '立省 ¥36.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/t/h/that-girl__1.jpg', 'Pony Effect ', 'THAT GIRL臻至口红', '¥89.00', '¥178.00', '立省 ¥50.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_122.jpg', 'Pony Effect ', '丝绒粉饼', '¥89.00', '¥248.00', '立省 ¥92.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_144.jpg', 'Pony Effect ', '双用眼影笔', '¥89.00', '¥118.00', '立省 ¥29.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_148.jpg', 'Pony Effect ', '密肌无痕粉底液', '¥89.00', '¥248.00', '立省 ¥97.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/o/pony-effect-__1_5.jpg', 'Pony Effect ', '丝绒遮瑕粉饼', '¥89.00', '¥248.00', '立省 ¥111.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/o/pony-effect__4.jpg', 'Pony Effect ', '持久遮瑕妆前乳', '¥89.00', '', 'Regular Price:', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/-/_-thumbnail.jpg', 'Pony Effect ', '迷恋迷你化妆镜', '¥89.00', '', 'Regular Price:', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/-/_-square.jpg', 'Pony Effect ', '轻盈持久遮瑕膏', '¥89.00', '¥138.00', '立省 ¥41.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/s/q/square_6.jpg', 'Pony Effect ', '灵感无限眼影霜', '¥89.00', '', 'Regular Price:', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/o/pony-effect-_-_106_1.jpg', 'Pony Effect ', '磁铁粉底刷#106', '¥89.00', '', 'Regular Price:', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/o/pony-effect-__1_7.jpg', 'Pony Effect ', '玩转色彩轻巧调色板/抹刀组合', '¥89.00', '', 'Regular Price:', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/p/o/pony-effect-__1_11.jpg', 'Pony Effect ', '自然纯净卸妆油', '¥89.00', '美美箱优惠价', '立省 ¥52.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_199_24.jpg', 'Pony Effect ', '便携式化妆刷组合', '¥89.00', '', 'Regular Price:', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/f/i/file_187_6.jpg', 'Pony Effect ', '藏蓝色水光双面粉扑', '¥89.00', '美美箱优惠价', '立省 ¥0.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/t/h/thumbnail-change300-02_2_1.jpg', 'Pony Effect ', 'THAT GIRL限量版7件套 # 初恋粉色', '¥89.00', '美美箱优惠价', '立省 ¥0.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51001758.jpg', 'BODY FIT ', '贵爱娘夜用1包 （18片装）', '¥89.00', '¥52.00', '立省 ¥6.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51001757.jpg', 'BODY FIT ', '贵爱娘中型1包（20片装）', '¥89.00', '¥47.00', '立省 ¥4.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51003857.jpg', 'BODY FIT ', '-贵爱娘卫生护垫1包 （38片装）', '¥89.00', '¥40.00', '立省 ¥4.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51003863_3.jpg', 'BODY FIT ', '纯棉亲肤护翼夜用1包 （20片装）', '¥89.00', '¥45.00', '立省 ¥6.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51003861_1.jpg', 'BODY FIT ', '纯棉亲肤护翼日用小型1包 （16片装）', '¥89.00', '¥34.00', '立省 ¥3.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51003864.jpg', 'BODY FIT ', '纯棉亲肤护翼超长夜用1包 （12片装）', '¥89.00', '¥42.00', '立省 ¥8.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51003871.jpg', 'BODY FIT ', '瞬间吸收夜用1包 （16片装）', '¥89.00', '¥42.00', '立省 ¥4.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51003869.jpg', 'BODY FIT ', '瞬间吸收日用小型1包 （16片装）', '¥89.00', '¥38.00', '立省 ¥4.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51003872.jpg', 'BODY FIT ', '瞬间吸收超长夜用1包 （12片装）', '¥89.00', '¥45.00', '立省 ¥8.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/5/_51003870.jpg', 'BODY FIT ', '瞬间吸收日用中型1包 （16片装）', '¥89.00', '¥42.00', '立省 ¥5.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51003865_2.jpg', 'BODY FIT ', '天然纯棉无香护垫1包（40片装）', '¥89.00', '¥40.00', '立省 ¥9.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52000456.jpg', 'SKINFOOD 思亲肤 ', '皇家蜂蜜活颜精华保湿乳液', '¥89.00', '¥144.00', '立省 ¥17.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52000363.jpg', 'SKINFOOD 思亲肤 ', '乳木果倍润霜', '¥89.00', '¥80.00', '立省 ¥11.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/s/2/s2534_1.jpg', 'SKINFOOD 思亲肤 ', '咖啡紧肤霜（身体）', '¥89.00', '¥63.00', '立省 ¥1.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51001977.jpg', 'ELASTINE ', '茉莉花洗发水', '¥89.00', '¥104.00', '立省 ¥54.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/s/_s1997_1.jpg', 'INNISFREE 悦诗风吟 ', '山茶花滋润身体膏', '¥89.00', '¥180.00', '立省 ¥61.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/s/2/s2379_1_1.jpg', 'INNISFREE 悦诗风吟 ', '山茶花精华沐浴露', '¥89.00', '¥112.00', '立省 ¥3.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51003924_s2394.jpg', 'BAMBOO SALT 竹盐 ', '自然爽快香草牙膏 3支装', '¥89.00', '¥63.00', '立省 ¥17.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51002002_s753.jpg', 'PERIOE 倍瑞奥  ', '美白93%牙膏 - 薄荷香', '¥89.00', '¥55.00', '立省 ¥9.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51003868_1.jpg', 'HANGEUL ', '棉柔亲肤夜用1包 （10片装）', '¥89.00', '美美箱优惠价', '立省 -¥1.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51003867_1.jpg', 'HANGEUL ', '棉柔亲肤日用中型1包 （16片装）', '¥89.00', '¥50.00', '立省 ¥5.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/1/51001981_1.jpg', 'ELASTINE ', '头皮护理护发素', '¥89.00', '¥104.00', '立省 ¥54.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/s/2/s2001_1_1.jpg', 'INNISFREE 悦诗风吟 ', '济州薄荷绿茶清爽头皮清洁剂 3支', '¥89.00', '¥120.00', '立省 ¥11.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52001402.jpg', 'KWAILNARA 水果之乡 ', '乳木果黄金精华素', '¥89.00', '¥40.00', '立省 ¥3.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52001403.jpg', 'KWAILNARA 水果之乡 ', '乳木果修复精华素', '¥89.00', '¥40.00', '立省 ¥3.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/0/50004532_1.jpg', 'FROMNATURE ', '高浓度芦荟万用膏', '¥89.00', '¥55.00', '立省 ¥8.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52000400.jpg', 'FROMNATURE ', '顶级芦荟洗面奶', '¥89.00', '¥47.00', '立省 ¥2.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/s/2/s2521_1.jpg', 'SKINFOOD 思亲肤 ', '乳木果倍润身体喷雾', '¥89.00', '¥64.00', '立省 ¥1.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52002526_1.jpg', 'IT''S SKIN 伊思 ', '晶钻蜗牛美肌身体霜', '¥89.00', '¥128.00', '立省 ¥31.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52002694.jpg', 'DOCTORCOS 达特可思 ', '氨基酸核糖（第二代）', '¥89.00', '¥360.00', '立省 ¥246.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52002425.jpg', 'DIAFORCE ', '贵妇光彩美白护手霜', '¥89.00', '¥64.00', '立省 ¥24.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52002865.jpg', 'ROYAL SKIN 柔雅皇冠 ', '水润护手霜 (芒果香)', '¥89.00', '¥40.00', '立省 ¥7.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/b/d/bd97_1.jpg', 'The yeon ', '芦荟92%啫哩胶+黄瓜90%啫哩胶', '¥89.00', '¥134.00', '立省 ¥56.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52002938.jpg', 'KERASYS ', '营养保湿香水护发素', '¥89.00', '¥108.00', '立省 ¥53.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52002942.jpg', 'KERASYS ', '无硅油护发素 [控油去屑]', '¥89.00', '¥110.00', '立省 ¥51.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52002948.jpg', 'KERASYS ', '无硅油护发素 [水润滋养]', '¥89.00', '¥110.00', '立省 ¥51.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52002947_1.jpg', 'KERASYS ', '无硅油护发素 [顺滑光泽]', '¥89.00', '¥110.00', '立省 ¥68.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52001291_1.jpg', 'NATURE REPUBLIC 自然共和国 ', '摩洛哥坚果护发喷雾', '¥89.00', '¥62.00', '立省 ¥6.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52003641_1.jpg', 'Dr.FORHAIR ', '清爽头皮棒', '¥89.00', '¥30.00', '立省 ¥11.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52003642_1.jpg', 'Dr.FORHAIR ', '防脱发洗发精', '¥89.00', '美美箱优惠价', '立省 -¥9.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52003644.jpg', 'Dr.FORHAIR ', '头皮祛痘液', '¥89.00', '¥144.00', '立省 ¥41.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/d/v/dv64_1.jpg', 'Dr.FORHAIR  ', '清爽头皮棒 3个', '¥89.00', '¥60.00', '立省 ¥21.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52003024.jpg', 'REPIEL 莉碧儿 ', '椰子油滋养护理足膜 10片装', '¥89.00', '¥240.00', '立省 ¥135.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52003026.jpg', 'REPIEL 莉碧儿 ', '乳木果油亮泽指甲膜 10片装', '¥89.00', '¥160.00', '立省 ¥81.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52003428_1.jpg', 'IT''S SKIN 伊思 ', '清凉解压足贴', '¥89.00', '¥30.00', '立省 ¥1.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52003429_2.jpg', 'IT''S SKIN 伊思 ', '瘦身纤体热敷贴', '¥89.00', '美美箱优惠价', '立省 ¥0.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52002968.jpg', 'PORORO 波鲁鲁 ', '沐浴露', '¥89.00', '¥112.00', '立省 ¥42.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52003660.jpg', 'MISSHA 谜尚 ', 'Foot Doctor30分钟去角质足膜', '¥89.00', '¥52.00', '立省 ¥6.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/_/-/_-__7_11.jpg', 'ANGEL FACTORY ', '角质女的眼泪 腋下管理霜', '¥89.00', '¥200.00', '立省 ¥132.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52003337.jpg', 'SULWHASOO 雪花秀 ', '山茶花润发精油', '¥89.00', '¥300.00', '立省 ¥75.00', '');
INSERT INTO `lili` (`src`, `h3`, `h4`, `span`, `span1`, `p`, `button`) VALUES
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52000632.jpg', 'HELLO KITTY ', '凯蒂猫白色沐浴刷', '¥89.00', '¥144.00', '立省 ¥45.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52004450_1.jpg', 'THE FACE SHOP 菲诗小铺 ', '樱花护发喷雾', '¥89.00', '¥56.00', '立省 ¥5.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52004454.jpg', 'THE FACE SHOP 菲诗小铺 ', '爽身走珠液 RYAN款', '¥89.00', '¥72.00', '立省 ¥9.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52004674.jpg', 'NATURE REPUBLIC 自然共和国 ', '瘦身滚珠按摩啫喱', '¥89.00', '¥119.00', '立省 ¥33.00', ''),
('http://img-cn1001.memebox.com/media/catalog/product/cache/1/small_image/320x/9df78eab33525d08d6e5fb8d27136e95/5/2/52004678.jpg', 'NATURE REPUBLIC 自然共和国 ', '自然橄榄清凉头皮发膜', '¥89.00', '¥79.00', '立省 ¥16.00', '');

-- --------------------------------------------------------

--
-- 表的结构 `lunbo`
--

CREATE TABLE IF NOT EXISTS `lunbo` (
  `img` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` varchar(20) NOT NULL,
  `oldprice` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `lunbo`
--

INSERT INTO `lunbo` (`img`, `name`, `price`, `oldprice`) VALUES
('http://images.s.cn/images/goods/20150527/5037112fc4fdc075_210.jpg', 'NIKE耐克 跑鞋 中性 荧光黄', '￥359.00', '￥469.00'),
('http://images.s.cn/images/goods/20141204/3e1ff6ea8344a0d5_210.jpg', 'NIKE耐克 跑步鞋  相片蓝+黑+反射银', '￥499.00', '￥999.00'),
('http://images.s.cn/images/goods/20160413/a0b420f132db11b3_210.jpg', 'NIKE耐克 跑步鞋 男 黑+金属银+煤黑', '￥489.00', '￥669.00'),
('http://images.s.cn/images/goods/20160413/e29f29f08c2b09ab_210.jpg', 'NIKE耐克 跑步鞋 男 黑+金属银+煤黑', '￥469.00', '￥569.00'),
('http://images.s.cn/images/goods/20160419/4efc11247e7d00d5_210.jpg', 'NIKE耐克 跑步鞋 男 黑+白+深灰', '￥949.00', '￥1529.00'),
('http://images.s.cn/images/goods/20160722/120204a7d4418048_210.jpg', 'NIKE耐克 跑步鞋 男 黑+金属银+白+白', '￥379.00', '￥469.00'),
('http://images.s.cn/images/goods/20160802/90605b92af1bfa66_210.jpg', 'NIKE耐克 跑步鞋 男 煤黑+荧光黄+黑+白', '￥339.00', '￥469.00'),
('http://images.s.cn/images/goods/20161009/985b5d0fb6cfa7f0_210.jpg', 'NIKE耐克 跑步鞋 男 黑色+煤黑+狼灰', '￥679.00', '￥999.00'),
('http://images.s.cn/images/goods/20161011/8300b775cb490615_210.jpg', 'NIKE耐克 跑步鞋 男 冷灰+荷兰橙+煤黑+白', '￥399.00', '￥569.00'),
('http://images.s.cn/images/goods/20161011/d02bb9f1c21cd6eb_210.jpg', 'NIKE耐克 跑步鞋 男 黑+白+狼灰+荧光黄', '￥529.00', '￥769.00'),
('http://images.s.cn/images/goods/20161025/4bdfd5333fa16262_210.jpg', 'NIKE耐克 跑步鞋 男 黑+白+煤黑', '￥579.00', '￥869.00'),
('http://images.s.cn/images/goods/20161110/163881db1af6fae9_210.jpg', 'NIKE耐克 跑步鞋 男 宝蓝+深黑蓝+钴蓝色', '￥599.00', '￥849.00'),
('http://images.s.cn/images/goods/20161110/5d4d91207a3fba40_210.jpg', 'NIKE耐克 跑步鞋 男 宝蓝+白+湖蓝绿', '￥379.00', '￥499.00'),
('http://images.s.cn/images/goods/20161110/edf65c5f7ac7c959_210.jpg', 'NIKE耐克 跑步鞋 男 幽灵绿+黑+冷灰+白', '￥599.00', '￥969.00'),
('http://images.s.cn/images/goods/20161110/0346125cf8d67929_210.jpg', 'NIKE耐克 跑步鞋 男 黑+白', '￥679.00', '￥999.00'),
('http://images.s.cn/images/goods/20161110/cb2d8619c880918f_210.jpg', 'NIKE耐克 跑步鞋 男 深灰+白+亮桔橙+草坪橙', '￥599.00', '￥899.00'),
('http://images.s.cn/images/goods/20161124/2bc9cdf9365936ec_210.jpg', 'NIKE耐克 跑步鞋 男 黑+白+荷兰橙+狼灰+深灰', '￥679.00', '￥999.00'),
('http://images.s.cn/images/goods/20161122/2cca4feae604a94a_210.jpg', 'NIKE耐克 跑步鞋 男 卡其绿+红古铜+荧光黄+黑', '￥679.00', '￥999.00'),
('http://images.s.cn/images/goods/20161122/e7570fef7f031d4f_210.jpg', 'NIKE耐克 跑步鞋 男 荧光黄+红古铜+黑+冷灰', '￥529.00', '￥769.00'),
('http://images.s.cn/images/goods/20161223/5899a696e001a67c_210.jpg', 'NIKE耐克 跑步鞋 男 深藏青色+白色+蓝黑蓝', '￥359.00', '￥499.00'),
('http://images.s.cn/images/goods/20161223/6fc5eb43fb1df071_210.jpg', 'NIKE耐克 跑步鞋 男 蓝黑蓝+白+上等蓝', '￥399.00', '￥569.00'),
('http://images.s.cn/images/goods/20161223/1ddb52cd9e1770b6_210.jpg', 'NIKE耐克 跑步鞋 男 黑+白+深灰+狼灰+荧光黄', '￥599.00', '￥849.00');

-- --------------------------------------------------------

--
-- 表的结构 `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `phonename` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `register`
--

INSERT INTO `register` (`phonename`, `password`) VALUES
('13867168479', '123123'),
('13466552266', '25d55ad283aa400af464c76d713c07ad'),
('13498767890', 'fcea920f7412b5da7be0cf42b8c93759');
